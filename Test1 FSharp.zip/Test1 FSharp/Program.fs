﻿let salaries = [75000; 48000; 120000; 190000; 300113; 92000; 36000]

let highIncomeSalaries = List.filter (fun x -> x > 100000) salaries

let calculateTax salary =
    if salary <= 49020 then
        float salary * 0.15
    elif salary <= 98040 then
        (49020.0 * 0.15) + (float (salary - 49020) * 0.205)
    elif salary <= 151978 then
        (49020.0 * 0.15) + (49020.0 * 0.205) + (float (salary - 98040) * 0.26)
    elif salary <= 216511 then
        (49020.0 * 0.15) + (49020.0 * 0.205) + (53938.0 * 0.26) + (float (salary - 151978) * 0.29)
    else
        (49020.0 * 0.15) + (49020.0 * 0.205) + (53938.0 * 0.26) + (64533.0 * 0.29) + (float (salary - 216511) * 0.33)

let taxes = List.map calculateTax salaries

let adjustedSalaries = List.map (fun x -> if x < 49020 then x + 20000 else x) salaries

let filteredSalaries = List.filter (fun x -> x >= 50000 && x <= 100000) salaries
let sumFilteredSalaries = List.reduce (+) filteredSalaries

printfn "All Salaries: %A" salaries
printfn "High-income salaries: %A" highIncomeSalaries
printfn "All Salaries: %A" salaries
printfn "Taxes for all salaries: %A" taxes
printfn "All Salaries: %A" salaries
printfn "Adjusted salaries: %A" adjustedSalaries
printfn "All Salaries: %A" salaries
printfn "Sum of filtered salaries between $50,000 and $100,000: %d" sumFilteredSalaries



//tail recursion
let rec sumMultiplesOf3 n total =
    if n = 0 then
     total
    else
        sumMultiplesOf3 (n - 3) (total + n)

let result = sumMultiplesOf3 27 0
printfn "The sum of all multiples of 3 :- %d" result  